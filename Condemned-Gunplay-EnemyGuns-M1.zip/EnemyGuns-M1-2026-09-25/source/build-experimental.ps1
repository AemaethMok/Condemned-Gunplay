$ErrorActionPreference = 'Stop'

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Zig = Join-Path $ProjectRoot '.tools\ziglang\zig.exe'
$OutputDirectory = Join-Path $ProjectRoot 'dist-experimental'

if (-not (Test-Path -LiteralPath $Zig)) {
    throw "Zig was not found at $Zig."
}

New-Item -ItemType Directory -Force -Path $OutputDirectory | Out-Null

& $Zig cc -target x86-windows-gnu -std=gnu11 -O2 -Wall -Wextra -shared -s `
    (Join-Path $ProjectRoot 'src\payload.c') `
    -o (Join-Path $OutputDirectory 'CondemnedWeaponSwitcher.dll') `
    -luser32 -lkernel32
if ($LASTEXITCODE -ne 0) { throw 'Payload build failed.' }

$ImportLibrary = Join-Path $OutputDirectory 'payload.lib'
if (Test-Path -LiteralPath $ImportLibrary) {
    Remove-Item -LiteralPath $ImportLibrary -Force
}

& $Zig cc -target x86-windows-gnu -std=gnu11 -O2 -Wall -Wextra -s `
    (Join-Path $ProjectRoot 'src\controller.c') `
    -o (Join-Path $OutputDirectory 'CondemnedWeaponSwitcher-EnemyGuns-Test.exe') `
    '-Wl,/subsystem:windows' -luser32 -lkernel32 -lgdi32 -ladvapi32
if ($LASTEXITCODE -ne 0) { throw 'Controller build failed.' }

Get-FileHash -Algorithm SHA256 `
    (Join-Path $OutputDirectory 'CondemnedWeaponSwitcher-EnemyGuns-Test.exe'), `
    (Join-Path $OutputDirectory 'CondemnedWeaponSwitcher.dll')
