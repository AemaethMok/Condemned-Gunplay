#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>

#include "protocol.h"

/* Condemned: Criminal Origins 1.0.314.0 (Steam), GameServer.dll. */
#define EXPECTED_TIMESTAMP 0x43FCFFA5u
#define EXPECTED_IMAGE_SIZE 0x0028B000u
#define RVA_PLAYER_LIST_BEGIN 0x002526F0u
#define RVA_PLAYER_LIST_END   0x002526F4u
#define RVA_RESET_INVENTORY   0x00139B50u
#define RVA_ACQUIRE_WEAPON    0x00138620u
#define RVA_SET_AMMO          0x000C4650u
#define RVA_RELOAD_CLIP       0x00172320u
#define RVA_WEAPON_DB_GLOBAL  0x002548E4u
#define RVA_FIND_WEAPON_RECORD 0x001805E0u
#define RVA_AI_ADD_WEAPON      0x000BA190u
#define RVA_AI_DROP_WEAPONS    0x000B9510u
#define RVA_AI_REFRESH_WEAPONS 0x00009590u
#define RVA_CAI_VFTABLE        0x001B89F4u
#define RVA_CAI_ENGINE_MESSAGE 0x000135B0u

#define PLAYER_INVENTORY_OFFSET       0x2678u
#define INVENTORY_ARSENAL_PTR_OFFSET  0x10u
#define ARSENAL_CURRENT_RECORD_OFFSET 0x20u
#define ARSENAL_WEAPONS_PTR_OFFSET    0x24u
#define WEAPON_HAVE_OFFSET            0x3Cu
#define WEAPON_CLIP_OFFSET            0x40u
#define WEAPON_RECORD_OFFSET          0x50u
#define WEAPON_AMMO_RECORD_OFFSET     0x54u
#define WEAPON_DB_COUNT_OFFSET        0x4Cu

#define AI_WEAPON_MGR_OFFSET          0xD28u
#define AI_ACTION_STATE_OFFSET        0xD18u
#define AI_MODEL_INSTANCE_OFFSET      0xC6Cu
#define AI_WEAPON_CHANGED_OFFSET      0x1C4u

#define CWS_REFILL_TIMER_ID      ((UINT_PTR)0xC057314u)
#define CWS_REFILL_RETRY_MS      100u
#define CWS_REFILL_MAX_ATTEMPTS  30u
#define CWS_AI_GUN_PERCENT       70u
#define CWS_AI_UPDATE            2u
#define CWS_AI_INITIAL_UPDATE    1u
#define CWS_AI_SAFE_UPDATE_DELAY 15u
#define CWS_MAX_PENDING_AI       128u

typedef void (__attribute__((thiscall)) *ResetInventoryFn)(void *player, int remove_gear);
typedef void (__attribute__((thiscall)) *AcquireWeaponFn)(void *player, const char *weapon_name);
typedef int (__attribute__((thiscall)) *SetAmmoFn)(void *arsenal, void *ammo_record, int amount);
typedef void (__attribute__((thiscall)) *ReloadClipFn)(
    void *weapon,
    int play_reload,
    int new_ammo,
    void *ammo_record
);
typedef void *(__attribute__((thiscall)) *FindWeaponRecordFn)(
    void *weapon_database,
    const char *weapon_name
);
typedef void (__attribute__((thiscall)) *AIAddWeaponFn)(
    void *weapon_manager,
    void *weapon_record,
    const char *hand_name,
    int activate
);
typedef void (__attribute__((thiscall)) *AIDropWeaponsFn)(void *weapon_manager);
typedef void (__attribute__((thiscall)) *AIRefreshWeaponsFn)(void *ai);
typedef uint32_t (__attribute__((thiscall)) *AIEngineMessageFn)(
    void *ai,
    uint32_t message_id,
    void *message_data,
    float message_value
);

static HWND g_game_window;
static WNDPROC g_original_window_proc;
static UINT g_command_message;
static UINT g_status_message;
static UINT g_arm_ai_message;
static DWORD g_last_switch_tick;
static DWORD g_last_enemy_toggle_tick;
static UINT g_last_weapon_index = CWS_WEAPON_COUNT;
static UINT g_pending_refill_attempts;
static int g_pending_acquire_needed;
static UINT g_random_state;
static volatile LONG g_enemy_distribution_enabled = 1;
static volatile LONG g_spawned_ai_count;
static volatile LONG g_armed_ai_count;
static AIEngineMessageFn g_original_ai_engine_message;
static AIEngineMessageFn *g_ai_engine_message_slot;

typedef struct CwsPendingAI {
    BYTE *object;
    UINT updates_remaining;
} CwsPendingAI;

static CwsPendingAI g_pending_ai[CWS_MAX_PENDING_AI];
static UINT g_pending_ai_count;

static UINT next_random_value(void);

static int is_readable_range(const void *address, SIZE_T length) {
    MEMORY_BASIC_INFORMATION information;
    uintptr_t begin = (uintptr_t)address;
    uintptr_t end = begin + length;
    uintptr_t region_end;
    DWORD protection;

    if (!address || end < begin ||
        !VirtualQuery(address, &information, sizeof(information))) {
        return 0;
    }
    region_end = (uintptr_t)information.BaseAddress + information.RegionSize;
    protection = information.Protect & 0xffu;
    if (information.State != MEM_COMMIT || end > region_end ||
        (information.Protect & PAGE_GUARD) || protection == PAGE_NOACCESS) {
        return 0;
    }
    return protection == PAGE_READONLY || protection == PAGE_READWRITE ||
           protection == PAGE_WRITECOPY || protection == PAGE_EXECUTE_READ ||
           protection == PAGE_EXECUTE_READWRITE ||
           protection == PAGE_EXECUTE_WRITECOPY;
}

static UINT next_random_value(void) {
    UINT value = g_random_state;
    if (!value) {
        value = GetTickCount() ^ GetCurrentProcessId() ^ 0xA17E45u;
    }
    value ^= value << 13;
    value ^= value >> 17;
    value ^= value << 5;
    g_random_state = value;
    return value;
}

/*
 * CAI's MID_INITIALUPDATE produces one 70% roll. Selected AI wait for several
 * of their own update callbacks, then the actual weapon mutation is posted to
 * the game window. This keeps it outside the AI initialization/update stack
 * without returning to heap scans or background polling.
 */
static int arm_new_ai(BYTE *ai) {
    HMODULE server_module = GetModuleHandleW(L"GameServer.dll");
    BYTE *server_base = (BYTE *)server_module;
    BYTE *weapon_database;
    BYTE *action_state;
    BYTE *model_instance;
    void *weapon_manager;
    void *weapon_record;
    FindWeaponRecordFn find_weapon_record;
    AIDropWeaponsFn drop_weapons;
    AIAddWeaponFn add_weapon;
    AIRefreshWeaponsFn refresh_weapons;

    if (!InterlockedCompareExchange(&g_enemy_distribution_enabled, 1, 1) ||
        !server_base || !is_readable_range(ai, AI_WEAPON_MGR_OFFSET + sizeof(void *)) ||
        *(void **)ai != server_base + RVA_CAI_VFTABLE) {
        return 0;
    }

    weapon_database = *(BYTE **)(server_base + RVA_WEAPON_DB_GLOBAL);
    weapon_manager = *(void **)(ai + AI_WEAPON_MGR_OFFSET);
    action_state = *(BYTE **)(ai + AI_ACTION_STATE_OFFSET);
    model_instance = *(BYTE **)(ai + AI_MODEL_INSTANCE_OFFSET);
    if (!weapon_database || !weapon_manager || !action_state || !model_instance ||
        !is_readable_range(weapon_database, 0x50u) ||
        !is_readable_range(weapon_manager, sizeof(void *)) ||
        !is_readable_range(action_state, AI_WEAPON_CHANGED_OFFSET + 1u) ||
        !is_readable_range(model_instance, 0x1F5u)) {
        return 0;
    }

    find_weapon_record = (FindWeaponRecordFn)(server_base + RVA_FIND_WEAPON_RECORD);
    weapon_record = find_weapon_record(weapon_database, "colt45");
    if (!weapon_record) {
        return 0;
    }

    drop_weapons = (AIDropWeaponsFn)(server_base + RVA_AI_DROP_WEAPONS);
    add_weapon = (AIAddWeaponFn)(server_base + RVA_AI_ADD_WEAPON);
    refresh_weapons = (AIRefreshWeaponsFn)(server_base + RVA_AI_REFRESH_WEAPONS);
    drop_weapons(weapon_manager);
    add_weapon(weapon_manager, weapon_record, "RightHand", 1);
    refresh_weapons(ai);
    *(BYTE *)(action_state + AI_WEAPON_CHANGED_OFFSET) = 1;
    InterlockedIncrement(&g_armed_ai_count);
    return 1;
}

static void queue_new_ai(BYTE *ai) {
    UINT index;
    InterlockedIncrement(&g_spawned_ai_count);
    if (!InterlockedCompareExchange(&g_enemy_distribution_enabled, 1, 1) ||
        next_random_value() % 100u >= CWS_AI_GUN_PERCENT) {
        return;
    }
    for (index = 0; index < g_pending_ai_count; ++index) {
        if (g_pending_ai[index].object == ai) {
            return;
        }
    }
    if (g_pending_ai_count < CWS_MAX_PENDING_AI) {
        g_pending_ai[g_pending_ai_count].object = ai;
        g_pending_ai[g_pending_ai_count].updates_remaining = CWS_AI_SAFE_UPDATE_DELAY;
        ++g_pending_ai_count;
    }
}

static void schedule_pending_ai(BYTE *ai) {
    UINT index;
    for (index = 0; index < g_pending_ai_count; ++index) {
        CwsPendingAI *entry = &g_pending_ai[index];
        BYTE *model_instance;
        if (entry->object != ai) {
            continue;
        }
        if (entry->updates_remaining) {
            --entry->updates_remaining;
            return;
        }
        model_instance = *(BYTE **)(ai + AI_MODEL_INSTANCE_OFFSET);
        if (!model_instance || !is_readable_range(model_instance, 0x1F5u)) {
            return;
        }

        /* Remove before posting so weapon calls cannot recursively reschedule it. */
        g_pending_ai[index] = g_pending_ai[g_pending_ai_count - 1u];
        --g_pending_ai_count;
        PostMessageW(g_game_window, g_arm_ai_message, (WPARAM)ai, 0);
        return;
    }
}

static uint32_t __attribute__((thiscall)) hooked_ai_engine_message(
    void *ai,
    uint32_t message_id,
    void *message_data,
    float message_value
) {
    uint32_t result = g_original_ai_engine_message(
        ai,
        message_id,
        message_data,
        message_value
    );
    if (message_id == CWS_AI_INITIAL_UPDATE) {
        queue_new_ai((BYTE *)ai);
    } else if (message_id == CWS_AI_UPDATE) {
        schedule_pending_ai((BYTE *)ai);
    }
    return result;
}

static int install_ai_spawn_hook(HMODULE server_module) {
    BYTE *server_base = (BYTE *)server_module;
    AIEngineMessageFn *slot =
        (AIEngineMessageFn *)(server_base + RVA_CAI_VFTABLE + sizeof(void *));
    AIEngineMessageFn expected =
        (AIEngineMessageFn)(server_base + RVA_CAI_ENGINE_MESSAGE);
    DWORD old_protection;
    DWORD ignored;

    if (*slot != expected ||
        !VirtualProtect(slot, sizeof(*slot), PAGE_EXECUTE_READWRITE, &old_protection)) {
        return 0;
    }
    g_original_ai_engine_message = expected;
    g_ai_engine_message_slot = slot;
    *slot = hooked_ai_engine_message;
    FlushInstructionCache(GetCurrentProcess(), slot, sizeof(*slot));
    VirtualProtect(slot, sizeof(*slot), old_protection, &ignored);
    return 1;
}

static void remove_ai_spawn_hook(void) {
    DWORD old_protection;
    DWORD ignored;
    if (!g_ai_engine_message_slot || !g_original_ai_engine_message ||
        *g_ai_engine_message_slot != hooked_ai_engine_message ||
        !VirtualProtect(
            g_ai_engine_message_slot,
            sizeof(*g_ai_engine_message_slot),
            PAGE_EXECUTE_READWRITE,
            &old_protection
        )) {
        return;
    }
    *g_ai_engine_message_slot = g_original_ai_engine_message;
    FlushInstructionCache(
        GetCurrentProcess(),
        g_ai_engine_message_slot,
        sizeof(*g_ai_engine_message_slot)
    );
    VirtualProtect(
        g_ai_engine_message_slot,
        sizeof(*g_ai_engine_message_slot),
        old_protection,
        &ignored
    );
    g_ai_engine_message_slot = NULL;
    g_original_ai_engine_message = NULL;
}

typedef struct FindWindowContext {
    DWORD process_id;
    HWND window;
} FindWindowContext;

static BOOL CALLBACK enum_process_window(HWND window, LPARAM parameter) {
    FindWindowContext *context = (FindWindowContext *)parameter;
    DWORD owner_process_id = 0;
    wchar_t title[64];
    GetWindowThreadProcessId(window, &owner_process_id);
    if (owner_process_id == context->process_id && IsWindowVisible(window) && GetWindow(window, GW_OWNER) == NULL) {
        if (!context->window) {
            context->window = window;
        }
        if (GetWindowTextW(window, title, 64) && lstrcmpiW(title, L"Condemned") == 0) {
            context->window = window;
            return FALSE;
        }
    }
    return TRUE;
}

static HWND find_main_window_for_process(DWORD process_id) {
    FindWindowContext context;
    context.process_id = process_id;
    context.window = NULL;

    EnumWindows(enum_process_window, (LPARAM)&context);
    return context.window;
}

static int validate_server_module(HMODULE server_module) {
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)server_module;
    const IMAGE_NT_HEADERS32 *nt;
    if (!dos || dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return 0;
    }
    nt = (const IMAGE_NT_HEADERS32 *)((const BYTE *)server_module + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        return 0;
    }
    return nt->FileHeader.TimeDateStamp == EXPECTED_TIMESTAMP &&
           nt->OptionalHeader.SizeOfImage == EXPECTED_IMAGE_SIZE;
}

static CwsStatus get_game_player(BYTE **server_base_out, void **player_out) {
    HMODULE server_module;
    BYTE *server_base;
    void **players_begin;
    void **players_end;
    void *player;

    server_module = GetModuleHandleW(L"GameServer.dll");
    if (!server_module) {
        return CWS_NO_SERVER;
    }
    if (!validate_server_module(server_module)) {
        return CWS_UNSUPPORTED_SERVER;
    }

    server_base = (BYTE *)server_module;
    players_begin = *(void ***)(server_base + RVA_PLAYER_LIST_BEGIN);
    players_end = *(void ***)(server_base + RVA_PLAYER_LIST_END);
    if (!players_begin || !players_end || players_begin == players_end) {
        return CWS_NOT_READY;
    }
    if (players_end < players_begin || (SIZE_T)(players_end - players_begin) > 16u) {
        return CWS_NATIVE_STATE_INVALID;
    }
    player = *players_begin;
    if (!player) {
        return CWS_NOT_READY;
    }
    *server_base_out = server_base;
    *player_out = player;
    return CWS_OK;
}

static void *find_current_weapon(BYTE *server_base, void *player) {
    BYTE *inventory = (BYTE *)player + PLAYER_INVENTORY_OFFSET;
    BYTE *arsenal = *(BYTE **)(inventory + INVENTORY_ARSENAL_PTR_OFFSET);
    BYTE *weapon_db = *(BYTE **)(server_base + RVA_WEAPON_DB_GLOBAL);
    void *current_record;
    void **weapons;
    UINT weapon_count;
    UINT index;

    if (!arsenal || !weapon_db) {
        return NULL;
    }
    current_record = *(void **)(arsenal + ARSENAL_CURRENT_RECORD_OFFSET);
    weapons = *(void ***)(arsenal + ARSENAL_WEAPONS_PTR_OFFSET);
    weapon_count = *(unsigned char *)(weapon_db + WEAPON_DB_COUNT_OFFSET);
    if (!current_record || !weapons || !weapon_count || weapon_count > 128u) {
        return NULL;
    }
    for (index = 0; index < weapon_count; ++index) {
        BYTE *weapon = (BYTE *)weapons[index];
        if (weapon &&
            *(unsigned char *)(weapon + WEAPON_HAVE_OFFSET) &&
            *(void **)(weapon + WEAPON_RECORD_OFFSET) == current_record) {
            return weapon;
        }
    }
    return NULL;
}

static int give_current_weapon_ammo(BYTE *server_base, void *player) {
    BYTE *inventory = (BYTE *)player + PLAYER_INVENTORY_OFFSET;
    BYTE *arsenal = *(BYTE **)(inventory + INVENTORY_ARSENAL_PTR_OFFSET);
    SetAmmoFn set_ammo = (SetAmmoFn)(server_base + RVA_SET_AMMO);
    AcquireWeaponFn acquire_weapon = (AcquireWeaponFn)(server_base + RVA_ACQUIRE_WEAPON);
    ReloadClipFn reload_clip = (ReloadClipFn)(server_base + RVA_RELOAD_CLIP);
    void *weapon;
    void *ammo_record;
    int clip_capacity;

    weapon = find_current_weapon(server_base, player);
    if (!arsenal || !weapon) {
        return 0;
    }
    ammo_record = *(void **)((BYTE *)weapon + WEAPON_AMMO_RECORD_OFFSET);
    if (!ammo_record) {
        return 0;
    }

    /*
     * Temporarily fill this exact internal ammo record.  ReloadClip then uses
     * the weapon database's own ShotsPerClip value, which gives us the normal
     * full-load count without hard-coding capacities for individual guns.
     */
    set_ammo(arsenal, ammo_record, -1);
    reload_clip(weapon, 0, -1, NULL);
    clip_capacity = *(int *)((BYTE *)weapon + WEAPON_CLIP_OFFSET);
    if (clip_capacity <= 0) {
        return 0;
    }

    /* Condemned displays total remaining rounds, so keep only one full load. */
    set_ammo(arsenal, ammo_record, clip_capacity);

    /* Re-acquiring sends the reduced, realistic count to the client HUD. */
    if (g_last_weapon_index < CWS_WEAPON_COUNT) {
        acquire_weapon(player, CWS_WEAPONS[g_last_weapon_index].record_name);
    }
    reload_clip(weapon, 0, clip_capacity, NULL);
    return clip_capacity;
}

static CwsStatus refill_current_ammo(void) {
    BYTE *server_base;
    void *player;
    CwsStatus status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }
    return give_current_weapon_ammo(server_base, player) > 0
        ? CWS_AMMO_OK
        : CWS_AMMO_CLIP_EMPTY;
}

static CwsStatus acquire_pending_weapon(void) {
    BYTE *server_base;
    void *player;
    AcquireWeaponFn acquire_weapon;
    CwsStatus status;

    if (g_last_weapon_index >= CWS_WEAPON_COUNT) {
        return CWS_BAD_WEAPON;
    }
    status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }
    acquire_weapon = (AcquireWeaponFn)(server_base + RVA_ACQUIRE_WEAPON);
    acquire_weapon(player, CWS_WEAPONS[g_last_weapon_index].record_name);
    return CWS_OK;
}

static CwsStatus switch_weapon(UINT weapon_index) {
    BYTE *server_base;
    void *player;
    ResetInventoryFn reset_inventory;
    DWORD now;
    CwsStatus status;

    if (weapon_index >= CWS_WEAPON_COUNT) {
        return CWS_BAD_WEAPON;
    }

    now = GetTickCount();
    if ((DWORD)(now - g_last_switch_tick) < 250u) {
        return CWS_BUSY;
    }
    g_last_switch_tick = now;

    status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }

    /*
     * ResetInventory(false) is intentionally used instead of DropCurrentWeapon.
     * Its native implementation checks m_pAttachments before doing anything,
     * so this is safe while unarmed and preserves story/forensic gear.
     */
    reset_inventory = (ResetInventoryFn)(server_base + RVA_RESET_INVENTORY);
    reset_inventory(player, 0);
    g_last_weapon_index = weapon_index;

    /*
     * ResetInventory and AcquireWeapon are not issued in the same call stack.
     * Defer acquisition to WM_TIMER, then retry acquisition/refill until the
     * new CWeapon is current.
     */
    KillTimer(g_game_window, CWS_REFILL_TIMER_ID);
    g_pending_refill_attempts = CWS_REFILL_MAX_ATTEMPTS;
    g_pending_acquire_needed = 1;
    if (!SetTimer(g_game_window, CWS_REFILL_TIMER_ID, CWS_REFILL_RETRY_MS, NULL)) {
        g_pending_refill_attempts = 0;
        g_pending_acquire_needed = 0;
        return CWS_AMMO_CLIP_EMPTY;
    }
    return CWS_OK;
}

static DWORD WINAPI hotkey_poll_thread(void *unused) {
    unsigned char was_down[CWS_WEAPON_COUNT] = {0};
    unsigned char refill_was_down = 0;
    unsigned char arm_was_down = 0;
    (void)unused;

    while (g_game_window && IsWindow(g_game_window)) {
        int modifiers_down =
            (GetAsyncKeyState(VK_CONTROL) & 0x8000) &&
            (GetAsyncKeyState(VK_MENU) & 0x8000);
        UINT weapon_index;

        for (weapon_index = 0; weapon_index < CWS_WEAPON_COUNT; ++weapon_index) {
            int is_down = modifiers_down &&
                (GetAsyncKeyState('1' + weapon_index) & 0x8000);
            if (is_down && !was_down[weapon_index]) {
                /* The window procedure performs the game calls on its owner thread. */
                PostMessageW(g_game_window, g_command_message, (WPARAM)weapon_index, 0);
            }
            was_down[weapon_index] = (unsigned char)!!is_down;
        }
        {
            int refill_is_down = modifiers_down &&
                (GetAsyncKeyState('0') & 0x8000);
            if (refill_is_down && !refill_was_down) {
                PostMessageW(g_game_window, g_command_message, CWS_COMMAND_REFILL_AMMO, 0);
            }
            refill_was_down = (unsigned char)!!refill_is_down;
        }
        {
            int arm_is_down = modifiers_down &&
                (GetAsyncKeyState('9') & 0x8000);
            if (arm_is_down && !arm_was_down) {
                PostMessageW(g_game_window, g_command_message, CWS_COMMAND_ARM_ENEMIES, 0);
            }
            arm_was_down = (unsigned char)!!arm_is_down;
        }
        Sleep(10);
    }
    return 0;
}

static LRESULT CALLBACK hooked_window_proc(HWND window, UINT message, WPARAM wparam, LPARAM lparam) {
    if (message == g_arm_ai_message) {
        arm_new_ai((BYTE *)wparam);
        return 0;
    }
    if (message == WM_TIMER && wparam == CWS_REFILL_TIMER_ID) {
        CwsStatus status;
        if (g_pending_acquire_needed) {
            status = acquire_pending_weapon();
            if (status == CWS_OK) {
                g_pending_acquire_needed = 0;
            }
        } else {
            status = refill_current_ammo();
            if (status != CWS_AMMO_OK) {
                /* A missing current weapon means acquisition has not settled. */
                acquire_pending_weapon();
            }
        }
        if (status == CWS_AMMO_OK || g_pending_refill_attempts <= 1u) {
            KillTimer(window, CWS_REFILL_TIMER_ID);
            g_pending_refill_attempts = 0;
            g_pending_acquire_needed = 0;
        } else {
            --g_pending_refill_attempts;
        }
        return 0;
    }
    if (message == g_command_message) {
        CwsStatus status;
        LPARAM status_detail = (LPARAM)wparam;
        if ((UINT)wparam == CWS_COMMAND_REFILL_AMMO) {
            status = refill_current_ammo();
            if (status == CWS_AMMO_OK) {
                KillTimer(window, CWS_REFILL_TIMER_ID);
                g_pending_refill_attempts = 0;
                g_pending_acquire_needed = 0;
            }
        } else if ((UINT)wparam == CWS_COMMAND_ARM_ENEMIES) {
            DWORD now = GetTickCount();
            if ((DWORD)(now - g_last_enemy_toggle_tick) < 250u) {
                /* The controller hotkey and in-game poller may both fire. */
                return 0;
            } else {
                LONG was_enabled;
                g_last_enemy_toggle_tick = now;
                was_enabled = InterlockedCompareExchange(
                    &g_enemy_distribution_enabled,
                    1,
                    1
                );
                if (was_enabled) {
                    InterlockedExchange(&g_enemy_distribution_enabled, 0);
                    g_pending_ai_count = 0;
                    status = CWS_ENEMY_DISTRIBUTION_OFF;
                } else {
                    InterlockedExchange(&g_enemy_distribution_enabled, 1);
                    status = CWS_ENEMY_DISTRIBUTION_ON;
                }
                status_detail = MAKELPARAM(
                    (WORD)InterlockedCompareExchange(&g_armed_ai_count, 0, 0),
                    (WORD)InterlockedCompareExchange(&g_spawned_ai_count, 0, 0)
                );
            }
        } else {
            status = switch_weapon((UINT)wparam);
        }
        HWND reply_window = (HWND)lparam;
        if (reply_window && IsWindow(reply_window)) {
            PostMessageW(reply_window, g_status_message, (WPARAM)status, status_detail);
        }
        return 0;
    }
    return CallWindowProcW(g_original_window_proc, window, message, wparam, lparam);
}

static DWORD WINAPI initialization_thread(void *unused) {
    DWORD process_id = GetCurrentProcessId();
    (void)unused;

    g_command_message = RegisterWindowMessageW(CWS_COMMAND_MESSAGE);
    g_status_message = RegisterWindowMessageW(CWS_STATUS_MESSAGE);
    g_arm_ai_message = RegisterWindowMessageW(
        L"CondemnedWeaponSwitcher.v1.InternalArmAI"
    );
    if (!g_command_message || !g_status_message || !g_arm_ai_message) {
        return 1;
    }

    for (;;) {
        HWND window = find_main_window_for_process(process_id);
        if (window) {
            SetLastError(0);
            g_original_window_proc = (WNDPROC)SetWindowLongPtrW(
                window,
                GWLP_WNDPROC,
                (LONG_PTR)hooked_window_proc
            );
            if (g_original_window_proc || GetLastError() == 0) {
                HANDLE hotkey_thread;
                g_game_window = window;
                SetPropW(window, CWS_READY_PROPERTY, (HANDLE)1);
                hotkey_thread = CreateThread(NULL, 0, hotkey_poll_thread, NULL, 0, NULL);
                if (hotkey_thread) {
                    CloseHandle(hotkey_thread);
                }
                break;
            }
        }
        Sleep(250);
    }

    /* GameServer may appear slightly after the main window. */
    while (g_game_window && IsWindow(g_game_window)) {
        HMODULE server_module = GetModuleHandleW(L"GameServer.dll");
        if (server_module) {
            if (!validate_server_module(server_module)) {
                return 2;
            }
            return install_ai_spawn_hook(server_module) ? 0 : 3;
        }
        Sleep(25);
    }
    return 4;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        HANDLE thread;
        DisableThreadLibraryCalls(instance);
        thread = CreateThread(NULL, 0, initialization_thread, NULL, 0, NULL);
        if (thread) {
            CloseHandle(thread);
        }
    } else if (reason == DLL_PROCESS_DETACH && !reserved) {
        if (GetModuleHandleW(L"GameServer.dll")) {
            remove_ai_spawn_hook();
        }
        if (g_game_window && g_original_window_proc) {
            KillTimer(g_game_window, CWS_REFILL_TIMER_ID);
            RemovePropW(g_game_window, CWS_READY_PROPERTY);
            SetWindowLongPtrW(
                g_game_window,
                GWLP_WNDPROC,
                (LONG_PTR)g_original_window_proc
            );
        }
    }
    return TRUE;
}
