#pragma once

#include <windows.h>

#define CWS_COMMAND_MESSAGE L"CondemnedWeaponSwitcher.v1.Command"
#define CWS_STATUS_MESSAGE L"CondemnedWeaponSwitcher.v1.Status"
#define CWS_READY_PROPERTY L"CondemnedWeaponSwitcher.v1.Ready"
#define CWS_COMMAND_REFILL_AMMO 0x100u
#define CWS_COMMAND_ARM_ENEMIES 0x101u

typedef enum CwsStatus {
    CWS_OK = 1,
    CWS_NO_SERVER = 2,
    CWS_UNSUPPORTED_SERVER = 3,
    CWS_NOT_READY = 4,
    CWS_NATIVE_STATE_INVALID = 5,
    CWS_BUSY = 6,
    CWS_BAD_WEAPON = 7,
    CWS_AMMO_OK = 8,
    CWS_AMMO_CLIP_EMPTY = 9,
    CWS_ENEMIES_ARMED = 10,
    CWS_NO_ENEMIES = 11,
    CWS_ENEMY_WEAPON_UNAVAILABLE = 12,
    CWS_ENEMY_DISTRIBUTION_ON = 13,
    CWS_ENEMY_DISTRIBUTION_OFF = 14,
    CWS_ENEMY_REFRESH_COMPLETE = 15
} CwsStatus;

typedef struct CwsWeapon {
    const char *record_name;
    const wchar_t *display_name;
} CwsWeapon;

static const CwsWeapon CWS_WEAPONS[] = {
    {"colt45", L"柯尔特 .45"},
    {"revolver", L"左轮手枪"},
    {"Rifle", L"步枪"},
    {"Double_Barrel", L"双管霰弹枪"},
    {"sub_machine", L"冲锋枪"},
};

#define CWS_WEAPON_COUNT ((UINT)(sizeof(CWS_WEAPONS) / sizeof(CWS_WEAPONS[0])))
