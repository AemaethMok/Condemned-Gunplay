# EnemyGuns-M1

Frozen on 2026-09-25 as the first user-validated enemy-gun milestone.

## Validated behavior

- Target: Steam `Condemned: Criminal Origins` 1.0.314.0.
- Existing player weapon switcher and normal-capacity ammo refill remain working.
- Automatic enemy guns are enabled by default.
- Every `CAI` receives one roll during native initialization; 70% are selected.
- Selected AI wait for 15 real `MID_UPDATE` callbacks and a valid model instance.
- Weapon replacement is then posted to the game window and performed outside
  the AI callback stack.
- Selected AI drop their original weapon and receive `colt45` in `RightHand`.
- No heap scan, periodic memory scan, or manually timed enemy refresh is used.
- `Ctrl+Alt+9` only toggles automatic enemy guns on or off.

The user confirmed that this exact build works in game. Treat it as the stable
rollback point for the current development stage.

## Known scope

- The 70% roll applies to generic `CAI`; friendly or scripted AI may also be
  affected.
- Only Steam `GameServer.dll` timestamp `0x43FCFFA5`, image size `0x0028B000`,
  is accepted.
- This is a development milestone, not the existing Nexus release package.

## Restore

For a binary rollback, copy both files from `bin` together. Fully exit the game
before replacing the DLL.

For a source rollback, restore `source/src` and `source/build-experimental.ps1`,
then run the build script from the project root.

## Binary identity

- `CondemnedWeaponSwitcher-EnemyGuns-M1.exe`
  - SHA-256: `069239442892D69178914A82A42707AB516893C00A048AAE604596FE6D1C247B`
- `CondemnedWeaponSwitcher.dll`
  - SHA-256: `D3BE69B0E597EF822F481034230BB8DD0C2AC97344E02B62DFCD9A6ED34F8C28`
