# Condemned 武器切换器 / Condemned Weapon Switcher

## 中文说明

目标版本为 Steam 版 *Condemned: Criminal Origins* 1.0.314.0。本工具按“方案二”工作：清除当前武器和弹药，再调用游戏原生玩家背包函数取得指定枪械。

工具直接调用游戏自身的 `ResetInventory(false)`，然后调用 `AcquireWeapon`。重置函数在空手状态下也安全；`false` 参数保证它不会删除剧情/取证装备。

### 使用方法

1. 把 ZIP 解压到任意可写目录，保持 EXE 和 DLL 位于同一文件夹。不要直接在压缩包内运行。推荐直接解压到包含 `Condemned.exe` 的游戏根目录，这也是自动定位失败时的兜底安装方式。
2. 完全退出之前已注入过旧 DLL 的游戏进程。
3. 运行 `CondemnedWeaponSwitcher.exe`。
4. 点击“启动 / 注入 Condemned”。控制器会依次查找已运行的游戏、Windows 的 Steam 安装记录，以及工具同目录下的 `Condemned.exe`，然后等待主窗口初始化并自动注入。若仍无法定位，请手动启动游戏后再次点击该按钮。
5. 等待关卡加载完成并进入实际游玩状态。
6. 点击枪械按钮，或在游戏内按 `Ctrl+Alt+1` 至 `Ctrl+Alt+5`。
7. `Ctrl+Alt+0` 只给当前枪械补弹，不会清除或更换武器，可作为手动补弹备用键。

武器快捷键：`1` 柯尔特 .45、`2` 左轮手枪、`3` 步枪、`4` 双管霰弹枪、`5` 冲锋枪。

界面会按 Windows 显示语言自动选择中文或英文，也可以随时点击右上角的 `English` / `中文` 按钮切换。

游戏内快捷键由注入模块直接轮询，不依赖全屏模式可能拦截的外部全局热键消息。旧武器不会生成地面拾取物，而是直接消失；原有弹药也会清空。

清除旧武器后，MOD 会在下一次游戏窗口计时中取得新武器，并在武器尚未生成时重新请求。之后它每 100 毫秒检查一次，等待新武器真正成为当前武器后再自动补弹，成功后立即停止重试。补弹会读取当前武器的真实内部弹药记录，让原生 `CWeapon::ReloadClip` 根据数据库中的 `ShotsPerClip` 算出正常弹仓容量，并只保留一份正常满膛弹药，而不是统一填充 100 发。

每次更换 DLL 版本后都要完全退出并重新启动游戏；已经注入旧游戏进程的 DLL 不会被磁盘上的新文件自动替换。

### 兼容性与安全措施

- 精确目标：`GameServer.dll` 时间戳 `0x43FCFFA5`、映像大小 `0x0028B000`（Steam 游戏版本 1.0.314.0）。
- 指纹不匹配时，注入模块会拒绝调用游戏内部函数。
- 不覆盖或修改任何原始游戏文件。
- 工具自身没有联网、下载或自动更新功能；启动按钮只读取本机 Steam 安装记录并启动游戏程序。
- 控制器通过标准 `LoadLibraryW` 进程注入工作；即使源码完整可见，杀毒软件仍可能对这类行为给出启发式警报。

### 编译

```powershell
python -m pip install --target ".tools" ziglang
.\build.ps1
```

---

## English Instructions

This tool targets the Steam release of *Condemned: Criminal Origins* 1.0.314.0. It removes the current weapon and ammunition, then calls the game's native player-inventory function to grant the selected firearm.

The tool calls the game's own `ResetInventory(false)` followed by `AcquireWeapon`. The reset is safe while the player is unarmed; the `false` argument preserves story and forensic equipment.

### Usage

1. Extract the ZIP to any writable folder, keeping the EXE and DLL together. Do not run it from inside the archive. Extracting directly into the game folder containing `Condemned.exe` is recommended and also serves as the fallback installation method.
2. Fully exit any game process that previously loaded an older version of the DLL.
3. Run `CondemnedWeaponSwitcher.exe`.
4. Click **Launch / Inject Condemned**. The controller checks for a running game, the Windows Steam installation record, and then a `Condemned.exe` beside the tool. It waits for the main window and injects automatically. If the game still cannot be located, start it manually and click the button again.
5. Wait for the level to finish loading and enter active gameplay.
6. Click a weapon button, or press `Ctrl+Alt+1` through `Ctrl+Alt+5` in the game.
7. `Ctrl+Alt+0` refills only the current firearm without removing or replacing it, and remains available as a manual fallback.

Weapon hotkeys: `1` Colt .45, `2` Revolver, `3` Rifle, `4` Double-barrel Shotgun, `5` Submachine Gun.

The UI follows the Windows display language automatically. You can switch at any time with the `English` / `中文` button in the upper-right corner.

In-game hotkeys are polled directly by the injected module, so they do not depend on external global-hotkey messages that fullscreen mode may block. The old weapon disappears without creating a world pickup, and its ammunition is cleared.

After removing the old weapon, the mod grants the new one on the next game-window timer tick and requests it again if it has not appeared. It then checks every 100 milliseconds until the new weapon has actually become current, refills it, and stops retrying immediately. It reads the current weapon's real internal ammunition record and lets the native `CWeapon::ReloadClip` derive the normal capacity from the database `ShotsPerClip` value. It keeps one normal full load instead of giving every weapon 100 rounds.

After replacing the DLL, fully exit and restart the game. A DLL already loaded into an old game process is not replaced automatically by the file on disk.

### Compatibility and safety

- Exact target: `GameServer.dll` timestamp `0x43FCFFA5`, image size `0x0028B000` (Steam game version 1.0.314.0).
- The injected module refuses to call internal game functions when the fingerprint does not match.
- No original game files are overwritten or modified.
- The tool has no networking, download, or automatic-update functionality. The launch button only reads the local Steam installation record and starts the game executable.
- The controller injects through the standard `LoadLibraryW` mechanism. Antivirus software may still flag this behavior heuristically even though the complete source is available.

### Building

```powershell
python -m pip install --target ".tools" ziglang
.\build.ps1
```
