#!/usr/bin/env python3
"""List printable strings from a file or a byte range within a file."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("file", type=Path)
    parser.add_argument("--offset", type=lambda value: int(value, 0), default=0)
    parser.add_argument("--size", type=lambda value: int(value, 0))
    parser.add_argument("--filter", default="")
    parser.add_argument("--context", type=int, default=0)
    args = parser.parse_args()

    with args.file.open("rb") as stream:
        stream.seek(args.offset)
        data = stream.read(args.size)

    entries = [
        (match.start(), match.group().decode("ascii", "replace"))
        for match in re.finditer(rb"[ -~]{3,}", data)
    ]
    folded_filter = args.filter.casefold()
    selected = [
        index for index, (_, value) in enumerate(entries)
        if folded_filter in value.casefold()
    ]
    emitted: set[int] = set()
    for selected_index in selected:
        lo = max(0, selected_index - args.context)
        hi = min(len(entries), selected_index + args.context + 1)
        if args.context and emitted:
            print("--")
        for index in range(lo, hi):
            if index in emitted:
                continue
            emitted.add(index)
            offset, value = entries[index]
            print(f"0x{args.offset + offset:08X} {value}")


if __name__ == "__main__":
    main()
