#!/usr/bin/env python3
"""Small PE/x86 helper used while developing the Condemned weapon switcher.

It reports exact string locations, direct data references from executable code,
and a short disassembly around each reference.  Nothing is written to the game
directory.
"""

from __future__ import annotations

import argparse
import struct
from pathlib import Path

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32


def c_string(data: bytes, offset: int) -> bytes:
    end = data.find(b"\0", offset)
    return data[offset:] if end < 0 else data[offset:end]


def section_for_rva(pe: pefile.PE, rva: int):
    for section in pe.sections:
        lo = section.VirtualAddress
        hi = lo + max(section.Misc_VirtualSize, section.SizeOfRawData)
        if lo <= rva < hi:
            return section
    return None


def executable_sections(pe: pefile.PE):
    for section in pe.sections:
        if section.Characteristics & 0x20000000:
            yield section


def find_function_start(data: bytes, offset: int) -> int:
    signatures = (b"\x55\x8b\xec", b"\x53\x8b\xdc", b"\x56\x8b\xf1")
    lo = max(0, offset - 0x500)
    candidates = []
    for signature in signatures:
        cursor = lo
        while True:
            found = data.find(signature, cursor, offset + 1)
            if found < 0:
                break
            candidates.append(found)
            cursor = found + 1
    return max(candidates, default=max(0, offset - 0x40))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pe", type=Path)
    parser.add_argument("needles", nargs="+")
    parser.add_argument("--context", type=lambda value: int(value, 0), default=0x80)
    parser.add_argument("--list-filter", help="List printable strings containing this text")
    parser.add_argument("--call-target", type=lambda value: int(value, 0), help="List direct calls to this VA")
    parser.add_argument("--value-target", type=lambda value: int(value, 0), help="List executable references to this value")
    parser.add_argument("--disasm-va", type=lambda value: int(value, 0), help="Disassemble from this VA")
    parser.add_argument("--disasm-size", type=lambda value: int(value, 0), default=0x100)
    args = parser.parse_args()

    pe = pefile.PE(str(args.pe), fast_load=False)
    image_base = pe.OPTIONAL_HEADER.ImageBase
    raw = args.pe.read_bytes()
    disassembler = Cs(CS_ARCH_X86, CS_MODE_32)
    disassembler.detail = False

    print(f"image_base=0x{image_base:08X} timestamp=0x{pe.FILE_HEADER.TimeDateStamp:08X}")
    for section in pe.sections:
        name = section.Name.rstrip(b"\0").decode("ascii", "replace")
        print(
            f"section {name:8s} rva=0x{section.VirtualAddress:08X} "
            f"raw=0x{section.PointerToRawData:08X} size=0x{section.SizeOfRawData:X}"
        )

    if args.list_filter:
        import re

        folded_filter = args.list_filter.casefold()
        print(f"\n=== printable strings containing {args.list_filter!r} ===")
        for match in re.finditer(rb"[ -~]{5,}", raw):
            value = match.group().decode("ascii", "replace")
            if folded_filter in value.casefold():
                print(f"file+0x{match.start():X} {value}")

    if args.call_target is not None:
        print(f"\n=== direct calls to 0x{args.call_target:08X} ===")
        for section in executable_sections(pe):
            section_data = section.get_data()
            section_va = image_base + section.VirtualAddress
            for offset in range(len(section_data) - 5):
                if section_data[offset] != 0xE8:
                    continue
                displacement = struct.unpack_from("<i", section_data, offset + 1)[0]
                call_va = section_va + offset
                if call_va + 5 + displacement != args.call_target:
                    continue
                window_start = max(0, offset - 0x24)
                window = section_data[window_start : offset + 0x2C]
                for nearby in disassembler.disasm(window, section_va + window_start):
                    marker = ">" if nearby.address == call_va else " "
                    print(f" {marker} {nearby.address:08X}: {nearby.mnemonic:8s} {nearby.op_str}")
                print()

    if args.value_target is not None:
        print(f"\n=== references to 0x{args.value_target:08X} ===")
        packed_value = struct.pack("<I", args.value_target)
        for section in executable_sections(pe):
            section_data = section.get_data()
            section_va = image_base + section.VirtualAddress
            search_at = 0
            while True:
                offset = section_data.find(packed_value, search_at)
                if offset < 0:
                    break
                search_at = offset + 1
                ref_va = section_va + offset
                window_start = max(0, offset - 0x34)
                window = section_data[window_start : offset + 0x60]
                for nearby in disassembler.disasm(window, section_va + window_start):
                    marker = ">" if nearby.address <= ref_va < nearby.address + nearby.size else " "
                    print(f" {marker} {nearby.address:08X}: {nearby.mnemonic:8s} {nearby.op_str}")
                print()

    if args.disasm_va is not None:
        disasm_rva = args.disasm_va - image_base
        disasm_section = section_for_rva(pe, disasm_rva)
        print(f"\n=== disassembly at 0x{args.disasm_va:08X} ===")
        if disasm_section is None:
            print("address is outside the image")
        else:
            code = pe.get_data(disasm_rva, args.disasm_size)
            for instruction in disassembler.disasm(code, args.disasm_va):
                print(f"   {instruction.address:08X}: {instruction.mnemonic:8s} {instruction.op_str}")

    for needle_text in args.needles:
        needle = needle_text.encode("ascii")
        print(f"\n=== {needle_text!r} ===")
        start = 0
        while True:
            offset = raw.find(needle, start)
            if offset < 0:
                break
            start = offset + 1
            rva = pe.get_rva_from_offset(offset)
            va = image_base + rva
            print(f"string file+0x{offset:X} rva=0x{rva:X} va=0x{va:08X}: {c_string(raw, offset)!r}")
            packed = struct.pack("<I", va)
            for section in executable_sections(pe):
                section_data = section.get_data()
                search_at = 0
                while True:
                    ref_offset = section_data.find(packed, search_at)
                    if ref_offset < 0:
                        break
                    search_at = ref_offset + 1
                    ref_rva = section.VirtualAddress + ref_offset
                    ref_va = image_base + ref_rva
                    fn_offset = find_function_start(section_data, ref_offset)
                    disasm_start = max(fn_offset, ref_offset - args.context)
                    disasm_stop = min(len(section_data), ref_offset + args.context)
                    code = section_data[disasm_start:disasm_stop]
                    code_va = image_base + section.VirtualAddress + disasm_start
                    print(f"  xref va=0x{ref_va:08X}, probable-fn=0x{image_base + section.VirtualAddress + fn_offset:08X}")
                    for instruction in disassembler.disasm(code, code_va):
                        marker = ">" if instruction.address <= ref_va < instruction.address + instruction.size else " "
                        print(
                            f"   {marker} {instruction.address:08X}: "
                            f"{instruction.mnemonic:8s} {instruction.op_str}"
                        )


if __name__ == "__main__":
    main()
