#!/usr/bin/env python3
"""Verify that the installed GameServer.dll matches the prototype's RVAs."""

from __future__ import annotations

import argparse
import struct
from pathlib import Path

import pefile


EXPECTED_TIMESTAMP = 0x43FCFFA5
EXPECTED_IMAGE_SIZE = 0x0028B000
RVA_PLAYER_LIST_BEGIN = 0x002526F0
RVA_PLAYER_LIST_END = 0x002526F4
RVA_RESET_INVENTORY = 0x00139B50
RVA_ACQUIRE_WEAPON = 0x00138620
RVA_SET_AMMO = 0x000C4650
RVA_RELOAD_CLIP = 0x00172320


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("game_server", type=Path)
    args = parser.parse_args()

    pe = pefile.PE(str(args.game_server), fast_load=False)
    problems: list[str] = []
    if pe.FILE_HEADER.Machine != 0x14C:
        problems.append("not an x86 image")
    if pe.FILE_HEADER.TimeDateStamp != EXPECTED_TIMESTAMP:
        problems.append(
            f"timestamp 0x{pe.FILE_HEADER.TimeDateStamp:08X}, expected 0x{EXPECTED_TIMESTAMP:08X}"
        )
    if pe.OPTIONAL_HEADER.SizeOfImage != EXPECTED_IMAGE_SIZE:
        problems.append(
            f"image size 0x{pe.OPTIONAL_HEADER.SizeOfImage:X}, expected 0x{EXPECTED_IMAGE_SIZE:X}"
        )

    for name, rva in (
        ("player-list begin", RVA_PLAYER_LIST_BEGIN),
        ("player-list end", RVA_PLAYER_LIST_END),
    ):
        section = pe.get_section_by_rva(rva)
        if not section or not (section.Characteristics & 0x80000000):
            problems.append(f"{name} RVA is not in writable memory")

    for name, rva, prefix in (
        ("ResetInventory", RVA_RESET_INVENTORY, b"\x51\x55\x8B\xE9\x8B\x85\xFC\x07"),
        ("AcquireWeapon", RVA_ACQUIRE_WEAPON, b"\x51\x8B\x44\x24\x08\x85\xC0"),
        ("SetAmmo", RVA_SET_AMMO, b"\x56\x8B\x74\x24\x08\x85\xF6\x57"),
        ("ReloadClip", RVA_RELOAD_CLIP, b"\x83\xEC\x78\x53\x55\x56"),
    ):
        section = pe.get_section_by_rva(rva)
        if not section or not (section.Characteristics & 0x20000000):
            problems.append(f"{name} RVA is not executable")
        actual = pe.get_data(rva, len(prefix))
        if actual != prefix:
            problems.append(f"unexpected {name} prefix {actual.hex(' ')}")

    if problems:
        print("UNSUPPORTED")
        for problem in problems:
            print(f"- {problem}")
        raise SystemExit(1)

    print("SUPPORTED")
    print(f"timestamp=0x{EXPECTED_TIMESTAMP:08X}")
    print(f"image_size=0x{EXPECTED_IMAGE_SIZE:X}")
    print(f"player_list_rva=0x{RVA_PLAYER_LIST_BEGIN:X}..0x{RVA_PLAYER_LIST_END:X}")
    print(f"reset_inventory_rva=0x{RVA_RESET_INVENTORY:X}")
    print(f"acquire_weapon_rva=0x{RVA_ACQUIRE_WEAPON:X}")
    print(f"set_ammo_rva=0x{RVA_SET_AMMO:X}")
    print(f"reload_clip_rva=0x{RVA_RELOAD_CLIP:X}")


if __name__ == "__main__":
    main()
