# Nexus Mods upload copy / Nexus 发布页面文案

## Suggested title

Condemned Weapon Switcher - Five Firearms and Automatic Ammo

## Suggested one-line summary

Switch instantly between five firearms with in-game hotkeys, automatic normal-capacity ammo, safe unarmed handling, and a bilingual Chinese/English controller.

## Version

1.0.0

## English description

Condemned Weapon Switcher adds an external bilingual controller and in-game hotkeys for switching between five firearms in *Condemned: Criminal Origins*.

Available weapons:

- `Ctrl+Alt+1` — Colt .45
- `Ctrl+Alt+2` — Revolver
- `Ctrl+Alt+3` — Rifle
- `Ctrl+Alt+4` — Double-barrel Shotgun
- `Ctrl+Alt+5` — Submachine Gun
- `Ctrl+Alt+0` — Refill the current firearm without replacing it

Switching safely clears the current weapon while preserving story and forensic equipment, including when the player is unarmed. The selected weapon is granted through the game's native inventory functions. Ammo is filled automatically using that weapon's normal database magazine capacity rather than a universal 100-round value.

The controller detects the Windows display language and supports both English and Chinese. The language can also be changed manually from the upper-right button.

### Installation and use

1. Extract the archive and keep `CondemnedWeaponSwitcher.exe` and `CondemnedWeaponSwitcher.dll` together. Extracting them directly into the game folder containing `Condemned.exe` is recommended and provides a fallback if the Steam installation record cannot be read.
2. Fully close any previously running copy of the game.
3. Run `CondemnedWeaponSwitcher.exe`.
4. Click **Launch / Inject Condemned**. The tool checks for a running game, the Windows Steam installation record, and then a `Condemned.exe` beside the tool. If all three checks fail, start the game manually and click the button again.
5. Enter a loaded single-player level, then use the buttons or hotkeys above.

Do not run the EXE directly from inside the ZIP.

### Compatibility

- Tested only with the Steam 1.0.314.0 release.
- The tool verifies the `GameServer.dll` timestamp and image size before calling internal game functions. Unsupported builds are rejected.
- Windows only; the game and controller are 32-bit.

### Important antivirus note

This utility injects its companion DLL into the running game through Windows `LoadLibraryW` so that hotkeys and native inventory calls execute on the game thread. Antivirus products may flag this behavior heuristically. The utility has no networking, download, telemetry, or automatic-update functionality and does not replace any original game file.

### Uninstallation

Delete the extracted tool folder. No original game files or save files are modified.

## 中文简介

本工具为 *Condemned: Criminal Origins* 增加五把枪的一键切换、按武器正常弹仓容量自动补弹、空手安全处理，以及中英文双语控制器。

- `Ctrl+Alt+1` — 柯尔特 .45
- `Ctrl+Alt+2` — 左轮手枪
- `Ctrl+Alt+3` — 步枪
- `Ctrl+Alt+4` — 双管霰弹枪
- `Ctrl+Alt+5` — 冲锋枪
- `Ctrl+Alt+0` — 只补充当前枪械弹药

推荐把 EXE 和 DLL 直接解压到包含 `Condemned.exe` 的游戏根目录。运行 EXE 并点击“启动 / 注入 Condemned”；工具也会尝试从 Windows 的 Steam 安装记录定位游戏或连接已经运行的游戏。进入完成加载的单机关卡后即可使用按钮或快捷键。

仅验证 Steam 1.0.314.0。工具不会修改原始游戏文件或存档。由于它需要通过 `LoadLibraryW` 注入配套 DLL，部分杀毒软件可能产生启发式警报。

## Upload checklist (not part of the public description)

- Upload `CondemnedWeaponSwitcher-1.0.0.zip` as the main file.
- Optionally upload `CondemnedWeaponSwitcher-1.0.0-Source.zip` as a separate optional/source file. Do not place it inside the main archive.
- Suggested category: Utilities or Gameplay.
- The archive is not password protected and contains no nested archive or copyrighted game asset.
- Disclose the use of Codex and apply Nexus Mods' **AI-Generated Content** tag. Current Nexus submission rules require appropriate AI tagging for AI-generated code and page descriptions.
- Use real screenshots of the controller and in-game results. Do not use unrelated or misleading promotional images.
- State the tested game version clearly and do not claim support for untested releases.
