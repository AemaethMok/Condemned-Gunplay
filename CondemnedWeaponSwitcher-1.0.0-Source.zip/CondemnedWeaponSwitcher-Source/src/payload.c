#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdint.h>

#include "protocol.h"

/* Condemned: Criminal Origins 1.0.314.0 (Steam), GameServer.dll. */
#define EXPECTED_TIMESTAMP 0x43FCFFA5u
#define EXPECTED_IMAGE_SIZE 0x0028B000u
#define RVA_PLAYER_LIST_BEGIN 0x002526F0u
#define RVA_PLAYER_LIST_END   0x002526F4u
#define RVA_RESET_INVENTORY   0x00139B50u
#define RVA_ACQUIRE_WEAPON    0x00138620u
#define RVA_SET_AMMO          0x000C4650u
#define RVA_RELOAD_CLIP       0x00172320u
#define RVA_WEAPON_DB_GLOBAL  0x002548E4u

#define PLAYER_INVENTORY_OFFSET       0x2678u
#define INVENTORY_ARSENAL_PTR_OFFSET  0x10u
#define ARSENAL_CURRENT_RECORD_OFFSET 0x20u
#define ARSENAL_WEAPONS_PTR_OFFSET    0x24u
#define WEAPON_HAVE_OFFSET            0x3Cu
#define WEAPON_CLIP_OFFSET            0x40u
#define WEAPON_RECORD_OFFSET          0x50u
#define WEAPON_AMMO_RECORD_OFFSET     0x54u
#define WEAPON_DB_COUNT_OFFSET        0x4Cu

#define CWS_REFILL_TIMER_ID      ((UINT_PTR)0xC057314u)
#define CWS_REFILL_RETRY_MS      100u
#define CWS_REFILL_MAX_ATTEMPTS  30u

typedef void (__attribute__((thiscall)) *ResetInventoryFn)(void *player, int remove_gear);
typedef void (__attribute__((thiscall)) *AcquireWeaponFn)(void *player, const char *weapon_name);
typedef int (__attribute__((thiscall)) *SetAmmoFn)(void *arsenal, void *ammo_record, int amount);
typedef void (__attribute__((thiscall)) *ReloadClipFn)(
    void *weapon,
    int play_reload,
    int new_ammo,
    void *ammo_record
);

static HMODULE g_module;
static HWND g_game_window;
static WNDPROC g_original_window_proc;
static UINT g_command_message;
static UINT g_status_message;
static DWORD g_last_switch_tick;
static UINT g_last_weapon_index = CWS_WEAPON_COUNT;
static UINT g_pending_refill_attempts;
static int g_pending_acquire_needed;

typedef struct FindWindowContext {
    DWORD process_id;
    HWND window;
} FindWindowContext;

static BOOL CALLBACK enum_process_window(HWND window, LPARAM parameter) {
    FindWindowContext *context = (FindWindowContext *)parameter;
    DWORD owner_process_id = 0;
    wchar_t title[64];
    GetWindowThreadProcessId(window, &owner_process_id);
    if (owner_process_id == context->process_id && IsWindowVisible(window) && GetWindow(window, GW_OWNER) == NULL) {
        if (!context->window) {
            context->window = window;
        }
        if (GetWindowTextW(window, title, 64) && lstrcmpiW(title, L"Condemned") == 0) {
            context->window = window;
            return FALSE;
        }
    }
    return TRUE;
}

static HWND find_main_window_for_process(DWORD process_id) {
    FindWindowContext context;
    context.process_id = process_id;
    context.window = NULL;

    EnumWindows(enum_process_window, (LPARAM)&context);
    return context.window;
}

static int validate_server_module(HMODULE server_module) {
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)server_module;
    const IMAGE_NT_HEADERS32 *nt;
    if (!dos || dos->e_magic != IMAGE_DOS_SIGNATURE) {
        return 0;
    }
    nt = (const IMAGE_NT_HEADERS32 *)((const BYTE *)server_module + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC) {
        return 0;
    }
    return nt->FileHeader.TimeDateStamp == EXPECTED_TIMESTAMP &&
           nt->OptionalHeader.SizeOfImage == EXPECTED_IMAGE_SIZE;
}

static CwsStatus get_game_player(BYTE **server_base_out, void **player_out) {
    HMODULE server_module;
    BYTE *server_base;
    void **players_begin;
    void **players_end;
    void *player;

    server_module = GetModuleHandleW(L"GameServer.dll");
    if (!server_module) {
        return CWS_NO_SERVER;
    }
    if (!validate_server_module(server_module)) {
        return CWS_UNSUPPORTED_SERVER;
    }

    server_base = (BYTE *)server_module;
    players_begin = *(void ***)(server_base + RVA_PLAYER_LIST_BEGIN);
    players_end = *(void ***)(server_base + RVA_PLAYER_LIST_END);
    if (!players_begin || !players_end || players_begin == players_end) {
        return CWS_NOT_READY;
    }
    if (players_end < players_begin || (SIZE_T)(players_end - players_begin) > 16u) {
        return CWS_NATIVE_STATE_INVALID;
    }
    player = *players_begin;
    if (!player) {
        return CWS_NOT_READY;
    }
    *server_base_out = server_base;
    *player_out = player;
    return CWS_OK;
}

static void *find_current_weapon(BYTE *server_base, void *player) {
    BYTE *inventory = (BYTE *)player + PLAYER_INVENTORY_OFFSET;
    BYTE *arsenal = *(BYTE **)(inventory + INVENTORY_ARSENAL_PTR_OFFSET);
    BYTE *weapon_db = *(BYTE **)(server_base + RVA_WEAPON_DB_GLOBAL);
    void *current_record;
    void **weapons;
    UINT weapon_count;
    UINT index;

    if (!arsenal || !weapon_db) {
        return NULL;
    }
    current_record = *(void **)(arsenal + ARSENAL_CURRENT_RECORD_OFFSET);
    weapons = *(void ***)(arsenal + ARSENAL_WEAPONS_PTR_OFFSET);
    weapon_count = *(unsigned char *)(weapon_db + WEAPON_DB_COUNT_OFFSET);
    if (!current_record || !weapons || !weapon_count || weapon_count > 128u) {
        return NULL;
    }
    for (index = 0; index < weapon_count; ++index) {
        BYTE *weapon = (BYTE *)weapons[index];
        if (weapon &&
            *(unsigned char *)(weapon + WEAPON_HAVE_OFFSET) &&
            *(void **)(weapon + WEAPON_RECORD_OFFSET) == current_record) {
            return weapon;
        }
    }
    return NULL;
}

static int give_current_weapon_ammo(BYTE *server_base, void *player) {
    BYTE *inventory = (BYTE *)player + PLAYER_INVENTORY_OFFSET;
    BYTE *arsenal = *(BYTE **)(inventory + INVENTORY_ARSENAL_PTR_OFFSET);
    SetAmmoFn set_ammo = (SetAmmoFn)(server_base + RVA_SET_AMMO);
    AcquireWeaponFn acquire_weapon = (AcquireWeaponFn)(server_base + RVA_ACQUIRE_WEAPON);
    ReloadClipFn reload_clip = (ReloadClipFn)(server_base + RVA_RELOAD_CLIP);
    void *weapon;
    void *ammo_record;
    int clip_capacity;

    weapon = find_current_weapon(server_base, player);
    if (!arsenal || !weapon) {
        return 0;
    }
    ammo_record = *(void **)((BYTE *)weapon + WEAPON_AMMO_RECORD_OFFSET);
    if (!ammo_record) {
        return 0;
    }

    /*
     * Temporarily fill this exact internal ammo record.  ReloadClip then uses
     * the weapon database's own ShotsPerClip value, which gives us the normal
     * full-load count without hard-coding capacities for individual guns.
     */
    set_ammo(arsenal, ammo_record, -1);
    reload_clip(weapon, 0, -1, NULL);
    clip_capacity = *(int *)((BYTE *)weapon + WEAPON_CLIP_OFFSET);
    if (clip_capacity <= 0) {
        return 0;
    }

    /* Condemned displays total remaining rounds, so keep only one full load. */
    set_ammo(arsenal, ammo_record, clip_capacity);

    /* Re-acquiring sends the reduced, realistic count to the client HUD. */
    if (g_last_weapon_index < CWS_WEAPON_COUNT) {
        acquire_weapon(player, CWS_WEAPONS[g_last_weapon_index].record_name);
    }
    reload_clip(weapon, 0, clip_capacity, NULL);
    return clip_capacity;
}

static CwsStatus refill_current_ammo(void) {
    BYTE *server_base;
    void *player;
    CwsStatus status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }
    return give_current_weapon_ammo(server_base, player) > 0
        ? CWS_AMMO_OK
        : CWS_AMMO_CLIP_EMPTY;
}

static CwsStatus acquire_pending_weapon(void) {
    BYTE *server_base;
    void *player;
    AcquireWeaponFn acquire_weapon;
    CwsStatus status;

    if (g_last_weapon_index >= CWS_WEAPON_COUNT) {
        return CWS_BAD_WEAPON;
    }
    status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }
    acquire_weapon = (AcquireWeaponFn)(server_base + RVA_ACQUIRE_WEAPON);
    acquire_weapon(player, CWS_WEAPONS[g_last_weapon_index].record_name);
    return CWS_OK;
}

static CwsStatus switch_weapon(UINT weapon_index) {
    BYTE *server_base;
    void *player;
    ResetInventoryFn reset_inventory;
    DWORD now;
    CwsStatus status;

    if (weapon_index >= CWS_WEAPON_COUNT) {
        return CWS_BAD_WEAPON;
    }

    now = GetTickCount();
    if ((DWORD)(now - g_last_switch_tick) < 250u) {
        return CWS_BUSY;
    }
    g_last_switch_tick = now;

    status = get_game_player(&server_base, &player);
    if (status != CWS_OK) {
        return status;
    }

    /*
     * ResetInventory(false) is intentionally used instead of DropCurrentWeapon.
     * Its native implementation checks m_pAttachments before doing anything,
     * so this is safe while unarmed and preserves story/forensic gear.
     */
    reset_inventory = (ResetInventoryFn)(server_base + RVA_RESET_INVENTORY);
    reset_inventory(player, 0);
    g_last_weapon_index = weapon_index;

    /*
     * ResetInventory and AcquireWeapon are not issued in the same call stack.
     * Defer acquisition to WM_TIMER, then retry acquisition/refill until the
     * new CWeapon is current.
     */
    KillTimer(g_game_window, CWS_REFILL_TIMER_ID);
    g_pending_refill_attempts = CWS_REFILL_MAX_ATTEMPTS;
    g_pending_acquire_needed = 1;
    if (!SetTimer(g_game_window, CWS_REFILL_TIMER_ID, CWS_REFILL_RETRY_MS, NULL)) {
        g_pending_refill_attempts = 0;
        g_pending_acquire_needed = 0;
        return CWS_AMMO_CLIP_EMPTY;
    }
    return CWS_OK;
}

static DWORD WINAPI hotkey_poll_thread(void *unused) {
    unsigned char was_down[CWS_WEAPON_COUNT] = {0};
    unsigned char refill_was_down = 0;
    (void)unused;

    while (g_game_window && IsWindow(g_game_window)) {
        int modifiers_down =
            (GetAsyncKeyState(VK_CONTROL) & 0x8000) &&
            (GetAsyncKeyState(VK_MENU) & 0x8000);
        UINT weapon_index;

        for (weapon_index = 0; weapon_index < CWS_WEAPON_COUNT; ++weapon_index) {
            int is_down = modifiers_down &&
                (GetAsyncKeyState('1' + weapon_index) & 0x8000);
            if (is_down && !was_down[weapon_index]) {
                /* The window procedure performs the game calls on its owner thread. */
                PostMessageW(g_game_window, g_command_message, (WPARAM)weapon_index, 0);
            }
            was_down[weapon_index] = (unsigned char)!!is_down;
        }
        {
            int refill_is_down = modifiers_down &&
                (GetAsyncKeyState('0') & 0x8000);
            if (refill_is_down && !refill_was_down) {
                PostMessageW(g_game_window, g_command_message, CWS_COMMAND_REFILL_AMMO, 0);
            }
            refill_was_down = (unsigned char)!!refill_is_down;
        }
        Sleep(10);
    }
    return 0;
}

static LRESULT CALLBACK hooked_window_proc(HWND window, UINT message, WPARAM wparam, LPARAM lparam) {
    if (message == WM_TIMER && wparam == CWS_REFILL_TIMER_ID) {
        CwsStatus status;
        if (g_pending_acquire_needed) {
            status = acquire_pending_weapon();
            if (status == CWS_OK) {
                g_pending_acquire_needed = 0;
            }
        } else {
            status = refill_current_ammo();
            if (status != CWS_AMMO_OK) {
                /* A missing current weapon means acquisition has not settled. */
                acquire_pending_weapon();
            }
        }
        if (status == CWS_AMMO_OK || g_pending_refill_attempts <= 1u) {
            KillTimer(window, CWS_REFILL_TIMER_ID);
            g_pending_refill_attempts = 0;
            g_pending_acquire_needed = 0;
        } else {
            --g_pending_refill_attempts;
        }
        return 0;
    }
    if (message == g_command_message) {
        CwsStatus status;
        if ((UINT)wparam == CWS_COMMAND_REFILL_AMMO) {
            status = refill_current_ammo();
            if (status == CWS_AMMO_OK) {
                KillTimer(window, CWS_REFILL_TIMER_ID);
                g_pending_refill_attempts = 0;
                g_pending_acquire_needed = 0;
            }
        } else {
            status = switch_weapon((UINT)wparam);
        }
        HWND reply_window = (HWND)lparam;
        if (reply_window && IsWindow(reply_window)) {
            PostMessageW(reply_window, g_status_message, (WPARAM)status, (LPARAM)wparam);
        }
        return 0;
    }
    return CallWindowProcW(g_original_window_proc, window, message, wparam, lparam);
}

static DWORD WINAPI initialization_thread(void *unused) {
    DWORD process_id = GetCurrentProcessId();
    (void)unused;

    g_command_message = RegisterWindowMessageW(CWS_COMMAND_MESSAGE);
    g_status_message = RegisterWindowMessageW(CWS_STATUS_MESSAGE);
    if (!g_command_message || !g_status_message) {
        return 1;
    }

    for (;;) {
        HWND window = find_main_window_for_process(process_id);
        if (window) {
            SetLastError(0);
            g_original_window_proc = (WNDPROC)SetWindowLongPtrW(
                window,
                GWLP_WNDPROC,
                (LONG_PTR)hooked_window_proc
            );
            if (g_original_window_proc || GetLastError() == 0) {
                HANDLE hotkey_thread;
                g_game_window = window;
                SetPropW(window, CWS_READY_PROPERTY, (HANDLE)1);
                hotkey_thread = CreateThread(NULL, 0, hotkey_poll_thread, NULL, 0, NULL);
                if (hotkey_thread) {
                    CloseHandle(hotkey_thread);
                }
                return 0;
            }
        }
        Sleep(250);
    }
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        HANDLE thread;
        g_module = instance;
        DisableThreadLibraryCalls(instance);
        thread = CreateThread(NULL, 0, initialization_thread, NULL, 0, NULL);
        if (thread) {
            CloseHandle(thread);
        }
    } else if (reason == DLL_PROCESS_DETACH && g_game_window && g_original_window_proc) {
        KillTimer(g_game_window, CWS_REFILL_TIMER_ID);
        RemovePropW(g_game_window, CWS_READY_PROPERTY);
        SetWindowLongPtrW(g_game_window, GWLP_WNDPROC, (LONG_PTR)g_original_window_proc);
    }
    return TRUE;
}
