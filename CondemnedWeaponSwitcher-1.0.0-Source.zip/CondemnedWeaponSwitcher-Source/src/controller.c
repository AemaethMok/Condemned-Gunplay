#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <stdint.h>

#include "protocol.h"

#define WINDOW_CLASS_NAME L"CondemnedWeaponSwitcherController"
#define WINDOW_TITLE_ZH L"Condemned 武器切换器"
#define WINDOW_TITLE_EN L"Condemned Weapon Switcher"
#define GAME_EXE_NAME L"Condemned.exe"
#define GAME_UNINSTALL_KEY L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Steam App 4720"
#define PAYLOAD_NAME L"CondemnedWeaponSwitcher.dll"

#define ID_ATTACH 10
#define ID_REFILL_AMMO 11
#define ID_LANGUAGE 12
#define ID_WEAPON_BASE 100
#define ID_HOTKEY_BASE 200
#define ID_HOTKEY_REFILL 206
#define ID_STATUS 300
#define ID_TIMER 400

static HWND g_main_window;
static HWND g_status_label;
static HWND g_attach_button;
static HWND g_refill_button;
static HWND g_language_button;
static HWND g_weapon_buttons[CWS_WEAPON_COUNT];
static UINT g_command_message;
static UINT g_status_message;
static DWORD g_attach_process_id;
static DWORD g_attach_start_tick;
static int g_use_chinese;
static const wchar_t *g_status_zh =
    L"先点击“启动 / 注入”。切换会清掉当前武器和弹药，但保留剧情/取证装备；空手状态同样安全。";
static const wchar_t *g_status_en =
    L"Click Launch / Inject first. Switching removes the current weapon and ammo, but preserves story/forensic gear; unarmed state is safe.";

static const wchar_t *const g_weapon_names_en[CWS_WEAPON_COUNT] = {
    L"Colt .45",
    L"Revolver",
    L"Rifle",
    L"Double-barrel Shotgun",
    L"Submachine Gun"
};

static void set_status_bilingual(const wchar_t *chinese, const wchar_t *english) {
    g_status_zh = chinese;
    g_status_en = english;
    if (g_status_label) {
        SetWindowTextW(g_status_label, g_use_chinese ? g_status_zh : g_status_en);
    }
}

static void apply_language(void) {
    UINT index;
    wchar_t label[96];

    SetWindowTextW(g_main_window, g_use_chinese ? WINDOW_TITLE_ZH : WINDOW_TITLE_EN);
    SetWindowTextW(g_attach_button,
        g_use_chinese ? L"启动 / 注入 Condemned" : L"Launch / Inject Condemned");
    SetWindowTextW(g_language_button, g_use_chinese ? L"English" : L"中文");
    SetWindowTextW(g_refill_button,
        g_use_chinese ? L"Ctrl+Alt+0   补满当前枪械弹药" : L"Ctrl+Alt+0   Refill current weapon");
    for (index = 0; index < CWS_WEAPON_COUNT; ++index) {
        wsprintfW(
            label,
            L"Ctrl+Alt+%u   %s",
            index + 1,
            g_use_chinese ? CWS_WEAPONS[index].display_name : g_weapon_names_en[index]
        );
        SetWindowTextW(g_weapon_buttons[index], label);
    }
    SetWindowTextW(g_status_label, g_use_chinese ? g_status_zh : g_status_en);
}

static DWORD find_game_process(void) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W entry;
    if (snapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }
    ZeroMemory(&entry, sizeof(entry));
    entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (lstrcmpiW(entry.szExeFile, GAME_EXE_NAME) == 0) {
                CloseHandle(snapshot);
                return entry.th32ProcessID;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    return 0;
}

typedef struct FindWindowContext {
    DWORD process_id;
    HWND window;
} FindWindowContext;

static BOOL CALLBACK enum_game_window(HWND window, LPARAM parameter) {
    FindWindowContext *context = (FindWindowContext *)parameter;
    DWORD process_id = 0;
    wchar_t title[64];
    GetWindowThreadProcessId(window, &process_id);
    if (process_id == context->process_id && IsWindowVisible(window) && GetWindow(window, GW_OWNER) == NULL) {
        if (!context->window) {
            context->window = window;
        }
        if (GetWindowTextW(window, title, 64) && lstrcmpiW(title, L"Condemned") == 0) {
            context->window = window;
            return FALSE;
        }
    }
    return TRUE;
}

static HWND find_game_window(DWORD process_id) {
    FindWindowContext context;
    context.process_id = process_id;
    context.window = NULL;
    EnumWindows(enum_game_window, (LPARAM)&context);
    return context.window;
}

static uintptr_t find_remote_module(DWORD process_id, const wchar_t *module_name) {
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, process_id);
    MODULEENTRY32W entry;
    if (snapshot == INVALID_HANDLE_VALUE) {
        return 0;
    }
    ZeroMemory(&entry, sizeof(entry));
    entry.dwSize = sizeof(entry);
    if (Module32FirstW(snapshot, &entry)) {
        do {
            if (lstrcmpiW(entry.szModule, module_name) == 0) {
                uintptr_t result = (uintptr_t)entry.modBaseAddr;
                CloseHandle(snapshot);
                return result;
            }
        } while (Module32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    return 0;
}

static LPTHREAD_START_ROUTINE resolve_remote_load_library(DWORD process_id) {
    uintptr_t local_load_library = (uintptr_t)GetProcAddress(
        GetModuleHandleW(L"kernel32.dll"),
        "LoadLibraryW"
    );
    MEMORY_BASIC_INFORMATION memory_info;
    wchar_t owner_path[MAX_PATH];
    const wchar_t *owner_name;
    uintptr_t local_owner;
    uintptr_t remote_owner;

    if (!local_load_library ||
        !VirtualQuery((const void *)local_load_library, &memory_info, sizeof(memory_info))) {
        return NULL;
    }
    local_owner = (uintptr_t)memory_info.AllocationBase;
    if (!GetModuleFileNameW((HMODULE)local_owner, owner_path, MAX_PATH)) {
        return NULL;
    }
    owner_name = owner_path + lstrlenW(owner_path);
    while (owner_name > owner_path && owner_name[-1] != L'\\' && owner_name[-1] != L'/') {
        --owner_name;
    }
    remote_owner = find_remote_module(process_id, owner_name);
    if (!remote_owner) {
        return NULL;
    }
    return (LPTHREAD_START_ROUTINE)(
        remote_owner + (local_load_library - local_owner)
    );
}

static int get_payload_path(wchar_t *path, DWORD capacity) {
    DWORD length = GetModuleFileNameW(NULL, path, capacity);
    wchar_t *slash;
    if (!length || length >= capacity) {
        return 0;
    }
    slash = path + length;
    while (slash > path && slash[-1] != L'\\' && slash[-1] != L'/') {
        --slash;
    }
    *slash = L'\0';
    if (lstrlenW(path) + lstrlenW(PAYLOAD_NAME) + 1 >= (int)capacity) {
        return 0;
    }
    lstrcatW(path, PAYLOAD_NAME);
    return GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES;
}

static int inject_payload(DWORD process_id) {
    wchar_t payload_path[MAX_PATH];
    HANDLE process = NULL;
    HANDLE thread = NULL;
    void *remote_path = NULL;
    SIZE_T path_bytes;
    LPTHREAD_START_ROUTINE remote_load_library;
    DWORD thread_result = 0;
    int result = 0;

    if (find_remote_module(process_id, PAYLOAD_NAME)) {
        return 1;
    }
    if (!get_payload_path(payload_path, MAX_PATH)) {
        set_status_bilingual(
            L"控制器目录中缺少 CondemnedWeaponSwitcher.dll。",
            L"CondemnedWeaponSwitcher.dll is missing from the controller folder."
        );
        return 0;
    }

    process = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION |
        PROCESS_VM_WRITE | PROCESS_VM_READ,
        FALSE,
        process_id
    );
    if (!process) {
        set_status_bilingual(
            L"无法打开游戏进程；请尝试以管理员身份运行本工具。",
            L"Cannot open the game process; try running this tool as administrator."
        );
        goto cleanup;
    }

    path_bytes = ((SIZE_T)lstrlenW(payload_path) + 1u) * sizeof(wchar_t);
    remote_path = VirtualAllocEx(process, NULL, path_bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote_path || !WriteProcessMemory(process, remote_path, payload_path, path_bytes, NULL)) {
        set_status_bilingual(
            L"无法把注入模块路径写入游戏进程。",
            L"Cannot write the injection module path into the game process."
        );
        goto cleanup;
    }

    remote_load_library = resolve_remote_load_library(process_id);
    if (!remote_load_library) {
        set_status_bilingual(
            L"无法解析游戏进程中的 LoadLibraryW。",
            L"Cannot resolve LoadLibraryW in the game process."
        );
        goto cleanup;
    }
    thread = CreateRemoteThread(process, NULL, 0, remote_load_library, remote_path, 0, NULL);
    if (!thread || WaitForSingleObject(thread, 10000) != WAIT_OBJECT_0 ||
        !GetExitCodeThread(thread, &thread_result) || !thread_result) {
        set_status_bilingual(L"DLL 注入失败。", L"DLL injection failed.");
        goto cleanup;
    }

    result = 1;

cleanup:
    if (thread) CloseHandle(thread);
    if (remote_path && process) VirtualFreeEx(process, remote_path, 0, MEM_RELEASE);
    if (process) CloseHandle(process);
    return result;
}

static int get_game_install_directory(wchar_t *directory, DWORD capacity) {
    HKEY key = NULL;
    DWORD type = 0;
    DWORD bytes = capacity * sizeof(wchar_t);
    LONG result = RegOpenKeyExW(
        HKEY_LOCAL_MACHINE,
        GAME_UNINSTALL_KEY,
        0,
        KEY_QUERY_VALUE | KEY_WOW64_32KEY,
        &key
    );
    if (result != ERROR_SUCCESS) {
        result = RegOpenKeyExW(
            HKEY_LOCAL_MACHINE,
            GAME_UNINSTALL_KEY,
            0,
            KEY_QUERY_VALUE | KEY_WOW64_64KEY,
            &key
        );
    }
    if (result != ERROR_SUCCESS) {
        return 0;
    }
    result = RegQueryValueExW(
        key,
        L"InstallLocation",
        NULL,
        &type,
        (BYTE *)directory,
        &bytes
    );
    RegCloseKey(key);
    if (result != ERROR_SUCCESS || (type != REG_SZ && type != REG_EXPAND_SZ) ||
        bytes < sizeof(wchar_t)) {
        return 0;
    }
    directory[capacity - 1] = L'\0';
    return directory[0] != L'\0';
}

static DWORD launch_game_from_directory(const wchar_t *directory) {
    wchar_t executable[MAX_PATH];
    STARTUPINFOW startup;
    PROCESS_INFORMATION process_info;

    if (!directory ||
        lstrlenW(directory) + (int)lstrlenW(L"\\Condemned.exe") + 1 >= MAX_PATH) {
        return 0;
    }
    lstrcpyW(executable, directory);
    lstrcatW(executable, L"\\Condemned.exe");
    if (GetFileAttributesW(executable) == INVALID_FILE_ATTRIBUTES) {
        return 0;
    }

    ZeroMemory(&startup, sizeof(startup));
    ZeroMemory(&process_info, sizeof(process_info));
    startup.cb = sizeof(startup);
    if (!CreateProcessW(
            executable, NULL, NULL, NULL, FALSE, 0, NULL,
            directory, &startup, &process_info)) {
        return 0;
    }
    CloseHandle(process_info.hThread);
    CloseHandle(process_info.hProcess);
    return process_info.dwProcessId;
}

static DWORD launch_installed_game(void) {
    wchar_t directory[MAX_PATH];
    if (!get_game_install_directory(directory, MAX_PATH)) {
        return 0;
    }
    return launch_game_from_directory(directory);
}

static DWORD launch_game_beside_controller(void) {
    wchar_t directory[MAX_PATH];
    wchar_t *slash;
    DWORD length = GetModuleFileNameW(NULL, directory, MAX_PATH);

    if (!length || length >= MAX_PATH) {
        return 0;
    }
    slash = directory + length;
    while (slash > directory && slash[-1] != L'\\' && slash[-1] != L'/') {
        --slash;
    }
    if (slash == directory) {
        return 0;
    }
    if (slash == directory + 3 && directory[1] == L':') {
        *slash = L'\0';
    } else {
        slash[-1] = L'\0';
    }
    return launch_game_from_directory(directory);
}

static void attach_to_game(void) {
    DWORD process_id = find_game_process();
    KillTimer(g_main_window, ID_TIMER);
    if (!process_id) {
        process_id = launch_installed_game();
    }
    if (!process_id) {
        process_id = launch_game_beside_controller();
    }
    if (!process_id) {
        set_status_bilingual(
            L"无法定位游戏；请把 EXE 和 DLL 放入 Condemned 游戏根目录，或手动启动游戏后重试。",
            L"Game not found. Put the EXE and DLL in the Condemned game folder, or start the game manually and retry."
        );
        return;
    }
    g_attach_process_id = process_id;
    g_attach_start_tick = GetTickCount();
    if (process_id) {
        set_status_bilingual(
            L"已找到游戏；正在等待主窗口初始化……",
            L"Game found; waiting for its main window to initialize..."
        );
    }
    SetTimer(g_main_window, ID_TIMER, 300, NULL);
}

static void send_weapon_command(UINT weapon_index) {
    DWORD process_id = find_game_process();
    HWND game_window;
    if (!process_id) {
        set_status_bilingual(
            L"游戏尚未运行，请先点击“启动 / 注入”。",
            L"The game is not running; click Launch / Inject first."
        );
        return;
    }
    game_window = find_game_window(process_id);
    if (!game_window || !GetPropW(game_window, CWS_READY_PROPERTY)) {
        set_status_bilingual(
            L"游戏内桥接模块尚未就绪。",
            L"The in-game bridge is not ready yet."
        );
        return;
    }
    if (!PostMessageW(game_window, g_command_message, (WPARAM)weapon_index, (LPARAM)g_main_window)) {
        set_status_bilingual(
            L"无法向游戏发送武器请求。",
            L"Cannot send the weapon request to the game."
        );
        return;
    }
    set_status_bilingual(L"武器请求已发送……", L"Weapon request sent...");
}

static void send_refill_command(void) {
    DWORD process_id = find_game_process();
    HWND game_window;
    if (!process_id) {
        set_status_bilingual(
            L"游戏尚未运行，请先点击“启动 / 注入”。",
            L"The game is not running; click Launch / Inject first."
        );
        return;
    }
    game_window = find_game_window(process_id);
    if (!game_window || !GetPropW(game_window, CWS_READY_PROPERTY)) {
        set_status_bilingual(
            L"游戏内桥接模块尚未就绪。",
            L"The in-game bridge is not ready yet."
        );
        return;
    }
    if (!PostMessageW(game_window, g_command_message, CWS_COMMAND_REFILL_AMMO, (LPARAM)g_main_window)) {
        set_status_bilingual(
            L"无法向游戏发送补弹请求。",
            L"Cannot send the ammo request to the game."
        );
        return;
    }
    set_status_bilingual(L"补弹请求已发送……", L"Ammo request sent...");
}

static const wchar_t *status_text_zh(CwsStatus status) {
    switch (status) {
        case CWS_OK: return L"已装备所选枪械；切换完成后会自动装填正常满膛弹药。";
        case CWS_NO_SERVER: return L"GameServer.dll 尚未加载；进入关卡后重试。";
        case CWS_UNSUPPORTED_SERVER: return L"GameServer.dll 与 Steam 1.0.314.0 版本不匹配。";
        case CWS_NOT_READY: return L"尚未找到单机玩家对象；请等待关卡加载完成。";
        case CWS_NATIVE_STATE_INVALID: return L"玩家列表状态异常；已取消调用以防止崩溃。";
        case CWS_BUSY: return L"已忽略过快的重复请求（250 毫秒防抖）。";
        case CWS_BAD_WEAPON: return L"无效的武器选择。";
        case CWS_AMMO_OK: return L"已按该枪数据库弹仓容量装填一份正常满膛弹药。";
        case CWS_AMMO_CLIP_EMPTY: return L"内部补弹已执行，但当前服务器弹仓仍为 0；请把这条状态反馈给开发者。";
        default: return L"收到了未知的游戏内桥接响应。";
    }
}

static const wchar_t *status_text_en(CwsStatus status) {
    switch (status) {
        case CWS_OK: return L"Weapon equipped; one normal full load will be added automatically when the switch completes.";
        case CWS_NO_SERVER: return L"GameServer.dll is not loaded yet; enter a level and try again.";
        case CWS_UNSUPPORTED_SERVER: return L"GameServer.dll does not match Steam version 1.0.314.0.";
        case CWS_NOT_READY: return L"The single-player object was not found; wait for the level to finish loading.";
        case CWS_NATIVE_STATE_INVALID: return L"Player-list state is invalid; the native call was cancelled to prevent a crash.";
        case CWS_BUSY: return L"An excessively fast repeat request was ignored (250 ms debounce).";
        case CWS_BAD_WEAPON: return L"Invalid weapon selection.";
        case CWS_AMMO_OK: return L"Loaded one normal full magazine using this weapon's database capacity.";
        case CWS_AMMO_CLIP_EMPTY: return L"The internal refill ran, but the current server magazine is still 0; please report this status to the developer.";
        default: return L"Received an unknown response from the in-game bridge.";
    }
}

static LRESULT CALLBACK window_proc(HWND window, UINT message, WPARAM wparam, LPARAM lparam) {
    UINT index;
    if (message == g_status_message) {
        set_status_bilingual(
            status_text_zh((CwsStatus)wparam),
            status_text_en((CwsStatus)wparam)
        );
        return 0;
    }
    switch (message) {
        case WM_COMMAND:
            if (LOWORD(wparam) == ID_ATTACH) {
                attach_to_game();
                return 0;
            }
            if (LOWORD(wparam) == ID_REFILL_AMMO) {
                send_refill_command();
                return 0;
            }
            if (LOWORD(wparam) == ID_LANGUAGE) {
                g_use_chinese = !g_use_chinese;
                apply_language();
                return 0;
            }
            if (LOWORD(wparam) >= ID_WEAPON_BASE && LOWORD(wparam) < ID_WEAPON_BASE + CWS_WEAPON_COUNT) {
                send_weapon_command((UINT)LOWORD(wparam) - ID_WEAPON_BASE);
                return 0;
            }
            break;
        case WM_HOTKEY:
            if (wparam >= ID_HOTKEY_BASE && wparam < ID_HOTKEY_BASE + CWS_WEAPON_COUNT) {
                send_weapon_command((UINT)wparam - ID_HOTKEY_BASE);
                return 0;
            }
            if (wparam == ID_HOTKEY_REFILL) {
                send_refill_command();
                return 0;
            }
            break;
        case WM_TIMER:
            if (wparam == ID_TIMER) {
                HWND game_window;
                HANDLE process;

                if ((DWORD)(GetTickCount() - g_attach_start_tick) >= 60000u) {
                    KillTimer(window, ID_TIMER);
                    g_attach_process_id = 0;
                    set_status_bilingual(
                        L"等待游戏初始化超时；请确认游戏仍在运行后重试。",
                        L"Timed out waiting for game initialization; confirm the game is still running and retry."
                    );
                    return 0;
                }

                process = OpenProcess(SYNCHRONIZE, FALSE, g_attach_process_id);
                if (!process || WaitForSingleObject(process, 0) != WAIT_TIMEOUT) {
                    if (process) CloseHandle(process);
                    KillTimer(window, ID_TIMER);
                    g_attach_process_id = 0;
                    set_status_bilingual(
                        L"游戏进程已退出，已取消注入。",
                        L"The game process exited; injection was cancelled."
                    );
                    return 0;
                }
                CloseHandle(process);

                game_window = find_game_window(g_attach_process_id);
                if (!game_window) {
                    set_status_bilingual(
                        L"正在等待 Condemned 主窗口初始化……",
                        L"Waiting for the Condemned main window to initialize..."
                    );
                    return 0;
                }
                if (game_window && GetPropW(game_window, CWS_READY_PROPERTY)) {
                    KillTimer(window, ID_TIMER);
                    g_attach_process_id = 0;
                    set_status_bilingual(
                        L"已就绪。进入关卡后选择一把武器。",
                        L"Ready. Enter a level, then select a weapon."
                    );
                    return 0;
                }

                if (!find_remote_module(g_attach_process_id, PAYLOAD_NAME)) {
                    set_status_bilingual(
                        L"主窗口已就绪；正在注入游戏内桥接模块……",
                        L"Main window ready; injecting the in-game bridge..."
                    );
                    if (!inject_payload(g_attach_process_id)) {
                        /* Early initialization failures are transient; retry until timeout. */
                        return 0;
                    }
                }

                set_status_bilingual(
                    L"注入成功；正在等待游戏内桥接模块就绪……",
                    L"Injection succeeded; waiting for the in-game bridge..."
                );
                return 0;
            }
            break;
        case WM_DESTROY:
            for (index = 0; index < CWS_WEAPON_COUNT; ++index) {
                UnregisterHotKey(window, ID_HOTKEY_BASE + index);
            }
            UnregisterHotKey(window, ID_HOTKEY_REFILL);
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProcW(window, message, wparam, lparam);
}

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previous, LPSTR command_line, int show_command) {
    WNDCLASSEXW window_class;
    MSG message;
    HFONT font;
    UINT index;
    (void)previous;
    (void)command_line;

    g_use_chinese = PRIMARYLANGID(GetUserDefaultUILanguage()) == LANG_CHINESE;
    g_command_message = RegisterWindowMessageW(CWS_COMMAND_MESSAGE);
    g_status_message = RegisterWindowMessageW(CWS_STATUS_MESSAGE);

    ZeroMemory(&window_class, sizeof(window_class));
    window_class.cbSize = sizeof(window_class);
    window_class.hInstance = instance;
    window_class.lpfnWndProc = window_proc;
    window_class.lpszClassName = WINDOW_CLASS_NAME;
    window_class.hCursor = LoadCursorW(NULL, MAKEINTRESOURCEW(32512));
    window_class.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    window_class.hIcon = LoadIconW(NULL, MAKEINTRESOURCEW(32512));
    if (!RegisterClassExW(&window_class)) {
        return 1;
    }

    g_main_window = CreateWindowExW(
        0, WINDOW_CLASS_NAME, g_use_chinese ? WINDOW_TITLE_ZH : WINDOW_TITLE_EN,
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 430, 430,
        NULL, NULL, instance, NULL
    );
    if (!g_main_window) {
        return 1;
    }

    font = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    g_attach_button = CreateWindowExW(
        0, L"BUTTON", L"启动 / 注入 Condemned",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        18, 16, 278, 34,
        g_main_window, (HMENU)(uintptr_t)ID_ATTACH, instance, NULL
    );
    SendMessageW(g_attach_button, WM_SETFONT, (WPARAM)font, TRUE);

    g_language_button = CreateWindowExW(
        0, L"BUTTON", L"English",
        WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        304, 16, 94, 34,
        g_main_window, (HMENU)(uintptr_t)ID_LANGUAGE, instance, NULL
    );
    SendMessageW(g_language_button, WM_SETFONT, (WPARAM)font, TRUE);

    for (index = 0; index < CWS_WEAPON_COUNT; ++index) {
        g_weapon_buttons[index] = CreateWindowExW(
            0, L"BUTTON", L"",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            18 + (int)(index % 2) * 194,
            68 + (int)(index / 2) * 52,
            186, 38,
            g_main_window,
            (HMENU)(uintptr_t)(ID_WEAPON_BASE + index),
            instance,
            NULL
        );
        SendMessageW(g_weapon_buttons[index], WM_SETFONT, (WPARAM)font, TRUE);
        RegisterHotKey(g_main_window, ID_HOTKEY_BASE + index, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, '1' + index);
    }

    {
        g_refill_button = CreateWindowExW(
            0, L"BUTTON", L"Ctrl+Alt+0   补满当前枪械弹药",
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            18, 224, 380, 34,
            g_main_window, (HMENU)(uintptr_t)ID_REFILL_AMMO, instance, NULL
        );
        SendMessageW(g_refill_button, WM_SETFONT, (WPARAM)font, TRUE);
        RegisterHotKey(g_main_window, ID_HOTKEY_REFILL, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, '0');
    }

    g_status_label = CreateWindowExW(
        0, L"STATIC",
        L"先点击“启动 / 注入”。切换会清掉当前武器和弹药，但保留剧情/取证装备；空手状态同样安全。",
        WS_CHILD | WS_VISIBLE | SS_LEFT,
        18, 276, 380, 80,
        g_main_window, (HMENU)(uintptr_t)ID_STATUS, instance, NULL
    );
    SendMessageW(g_status_label, WM_SETFONT, (WPARAM)font, TRUE);
    apply_language();

    ShowWindow(g_main_window, show_command);
    UpdateWindow(g_main_window);
    while (GetMessageW(&message, NULL, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return (int)message.wParam;
}
